package com.example.faultisolation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class view_notification_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_notification_activity);
    }
}
