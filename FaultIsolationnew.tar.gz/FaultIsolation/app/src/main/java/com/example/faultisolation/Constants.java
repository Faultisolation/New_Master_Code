package com.example.faultisolation;

public class Constants {
    public static final String LOGIN_FLAG = "login_flag";
    public static final  String UId = "";
    public static final String type = "";
    public static  final String PREF_NAME="faultisolation_preferance";



}
