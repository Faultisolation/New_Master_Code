package com.example.faultisolation;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.ksoap2.serialization.SoapObject;


public class predict_activity extends AppCompatActivity implements View.OnClickListener {
    EditText editText;
    Button balert;
    Spinner sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_predict_activity);
        try
        {
            if(android.os.Build.VERSION.SDK_INT>9)
            {
                StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
            }
        }
        catch (Exception e)
        {


        }
        initdata();
    }

    private void initdata() {
        editText=findViewById(R.id.edittext);
        balert=findViewById(R.id.balert);
        sp=(findViewById(R.id.spinner2));
        balert.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        String val=new PreferenceHelper(predict_activity.this).getString(Constants.UId);
        if(!editText.getText().toString().equals("")) {

            SoapObject sobj = new SoapObject(soapclass.NAMESPACE, "predict");
            soapclass sc = new soapclass();
            sobj.addProperty("eidd", val);
            sobj.addProperty("pdecri", editText.getText().toString());
            sobj.addProperty("macna",sp.getSelectedItem().toString() );
            String ou = sc.Callsoap(sobj, "http://tempuri.org/predict");
            if (ou.equals("error") || ou.equals("")) {
                Toast.makeText(getApplicationContext(), "Try Again....", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "Successfully Posted the prediction", Toast.LENGTH_LONG).show();
            }
        }
        else{
            editText.setError("Description field is required");
            editText.requestFocus();
        }

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
